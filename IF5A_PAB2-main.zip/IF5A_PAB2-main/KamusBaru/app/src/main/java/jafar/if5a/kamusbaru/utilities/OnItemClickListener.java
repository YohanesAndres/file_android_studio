package jafar.if5a.kamusbaru.utilities;

public interface OnItemClickListener<T>{
    void onItemClick(T data, int position);
}
