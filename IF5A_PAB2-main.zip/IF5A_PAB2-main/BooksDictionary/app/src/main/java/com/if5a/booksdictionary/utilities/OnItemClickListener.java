package com.if5a.booksdictionary.utilities;

public interface OnItemClickListener<T> {
    void onItemClick(T data, int position);
}