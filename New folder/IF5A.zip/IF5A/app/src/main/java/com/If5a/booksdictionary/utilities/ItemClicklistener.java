package com.If5a.booksdictionary.utilities;

public interface ItemClicklistener <T>{
    void onItemClick(T data, int position);
}
